clear all;
close all;
clc;

rtwbuild('Senior_Design_G4');
tg.load('Senior_Design_G4');
tg.start;

ECE495_Final