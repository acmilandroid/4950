function ri = Senior_Design_G4ri

ri = [];

